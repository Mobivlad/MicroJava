// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.NodeCost;
import ukr.lpu.cs.mj.nodes.statements.MJIncrementStatement;

@GeneratedBy(MJIncrementStatement.class)
public final class MJIncrementStatementNodeGen extends MJIncrementStatement {

    private MJIncrementStatementNodeGen(String varName) {
        super(varName);
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        doInc(frameValue);
        return;
    }

    @Override
    public NodeCost getCost() {
        return NodeCost.MONOMORPHIC;
    }

    public static MJIncrementStatement create(String varName) {
        return new MJIncrementStatementNodeGen(varName);
    }

}
