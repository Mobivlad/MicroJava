// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.MJSymbolNode;
import ukr.lpu.cs.mj.nodes.statements.MJAssignStatementNode;

@GeneratedBy(MJAssignStatementNode.class)
public final class MJAssignStatementNodeGen extends MJAssignStatementNode {

    @Child private MJExpressionNode symbol_;
    @Child private MJExpressionNode expression_;
    @CompilationFinal private int state_;

    private MJAssignStatementNodeGen(MJExpressionNode symbol, MJExpressionNode expression) {
        this.symbol_ = symbol;
        this.expression_ = expression;
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        int state = state_;
        Object symbolValue_ = this.symbol_.execute(frameValue);
        int expressionValue_;
        try {
            expressionValue_ = this.expression_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(symbolValue_, ex.getResult());
            return;
        }
        if (state != 0 /* is-active doAssign(MJSymbolNode, int) */ && symbolValue_ instanceof MJSymbolNode) {
            MJSymbolNode symbolValue__ = (MJSymbolNode) symbolValue_;
            doAssign(symbolValue__, expressionValue_);
            return;
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        executeAndSpecialize(symbolValue_, expressionValue_);
        return;
    }

    private void executeAndSpecialize(Object symbolValue, Object expressionValue) {
        int state = state_;
        if (symbolValue instanceof MJSymbolNode) {
            MJSymbolNode symbolValue_ = (MJSymbolNode) symbolValue;
            if (expressionValue instanceof Integer) {
                int expressionValue_ = (int) expressionValue;
                this.state_ = state = state | 0b1 /* add-active doAssign(MJSymbolNode, int) */;
                doAssign(symbolValue_, expressionValue_);
                return;
            }
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.symbol_, this.expression_}, symbolValue, expressionValue);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else {
            return NodeCost.MONOMORPHIC;
        }
    }

    public static MJAssignStatementNode create(MJExpressionNode symbol, MJExpressionNode expression) {
        return new MJAssignStatementNodeGen(symbol, expression);
    }

}
