package ukr.lpu.cs.mj.nodes;

import com.oracle.truffle.api.nodes.Node;

public abstract class MJNode extends Node {
}
