// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.expressions.operations;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.expressions.operations.MJNegateNode;

@GeneratedBy(MJNegateNode.class)
public final class MJNegateNodeGen extends MJNegateNode {

    @Child private MJExpressionNode op_;
    @CompilationFinal private int state_;

    private MJNegateNodeGen(MJExpressionNode op) {
        this.op_ = op;
    }

    @Override
    public Object execute(VirtualFrame frameValue) {
        int state = state_;
        if ((state & 0b10) == 0 /* only-active minus(int) */ && state != 0  /* is-not minus(int) && minus(double) */) {
            return execute_int0(frameValue, state);
        } else if ((state & 0b1) == 0 /* only-active minus(double) */ && state != 0  /* is-not minus(int) && minus(double) */) {
            return execute_double1(frameValue, state);
        } else {
            return execute_generic2(frameValue, state);
        }
    }

    private Object execute_int0(VirtualFrame frameValue, int state) {
        int opValue_;
        try {
            opValue_ = this.op_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(ex.getResult());
        }
        assert (state & 0b1) != 0 /* is-active minus(int) */;
        return minus(opValue_);
    }

    private Object execute_double1(VirtualFrame frameValue, int state) {
        double opValue_;
        try {
            opValue_ = this.op_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(ex.getResult());
        }
        assert (state & 0b10) != 0 /* is-active minus(double) */;
        return minus(opValue_);
    }

    private Object execute_generic2(VirtualFrame frameValue, int state) {
        Object opValue_ = this.op_.execute(frameValue);
        if ((state & 0b1) != 0 /* is-active minus(int) */ && opValue_ instanceof Integer) {
            int opValue__ = (int) opValue_;
            return minus(opValue__);
        }
        if ((state & 0b10) != 0 /* is-active minus(double) */ && opValue_ instanceof Double) {
            double opValue__ = (double) opValue_;
            return minus(opValue__);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(opValue_);
    }

    @Override
    public double executeDouble(VirtualFrame frameValue) throws UnexpectedResultException {
        int state = state_;
        double opValue_;
        try {
            opValue_ = this.op_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return expectDouble(executeAndSpecialize(ex.getResult()));
        }
        if ((state & 0b10) != 0 /* is-active minus(double) */) {
            return minus(opValue_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return expectDouble(executeAndSpecialize(opValue_));
    }

    @Override
    public int executeInt(VirtualFrame frameValue) throws UnexpectedResultException {
        int state = state_;
        int opValue_;
        try {
            opValue_ = this.op_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return expectInteger(executeAndSpecialize(ex.getResult()));
        }
        if ((state & 0b1) != 0 /* is-active minus(int) */) {
            return minus(opValue_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return expectInteger(executeAndSpecialize(opValue_));
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        int state = state_;
        try {
            if ((state & 0b10) == 0 /* only-active minus(int) */ && state != 0  /* is-not minus(int) && minus(double) */) {
                executeInt(frameValue);
                return;
            } else if ((state & 0b1) == 0 /* only-active minus(double) */ && state != 0  /* is-not minus(int) && minus(double) */) {
                executeDouble(frameValue);
                return;
            }
            execute(frameValue);
            return;
        } catch (UnexpectedResultException ex) {
            return;
        }
    }

    private Object executeAndSpecialize(Object opValue) {
        int state = state_;
        if (opValue instanceof Integer) {
            int opValue_ = (int) opValue;
            this.state_ = state = state | 0b1 /* add-active minus(int) */;
            return minus(opValue_);
        }
        if (opValue instanceof Double) {
            double opValue_ = (double) opValue;
            this.state_ = state = state | 0b10 /* add-active minus(double) */;
            return minus(opValue_);
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.op_}, opValue);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if ((state & (state - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    private static double expectDouble(Object value) throws UnexpectedResultException {
        if (value instanceof Double) {
            return (double) value;
        }
        throw new UnexpectedResultException(value);
    }

    private static int expectInteger(Object value) throws UnexpectedResultException {
        if (value instanceof Integer) {
            return (int) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static MJNegateNode create(MJExpressionNode op) {
        return new MJNegateNodeGen(op);
    }

}
