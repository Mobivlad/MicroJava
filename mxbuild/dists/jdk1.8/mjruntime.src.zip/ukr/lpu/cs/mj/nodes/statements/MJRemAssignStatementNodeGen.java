// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.expressions.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.statements.MJRemAssignStatementNode;

@GeneratedBy(MJRemAssignStatementNode.class)
public final class MJRemAssignStatementNodeGen extends MJRemAssignStatementNode {

    @Child private MJExpressionNode expression_;
    @CompilationFinal private int state_;

    private MJRemAssignStatementNodeGen(String varName, MJExpressionNode expression) {
        super(varName);
        this.expression_ = expression;
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        int state = state_;
        if ((state & 0b10) == 0 /* only-active doAssign(VirtualFrame, int) */ && state != 0  /* is-not doAssign(VirtualFrame, int) && doAssign(VirtualFrame, double) */) {
            executeVoid_int0(frameValue, state);
            return;
        } else if ((state & 0b1) == 0 /* only-active doAssign(VirtualFrame, double) */ && state != 0  /* is-not doAssign(VirtualFrame, int) && doAssign(VirtualFrame, double) */) {
            executeVoid_double1(frameValue, state);
            return;
        } else {
            executeVoid_generic2(frameValue, state);
            return;
        }
    }

    private void executeVoid_int0(VirtualFrame frameValue, int state) {
        int expressionValue_;
        try {
            expressionValue_ = this.expression_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(frameValue, ex.getResult());
            return;
        }
        assert (state & 0b1) != 0 /* is-active doAssign(VirtualFrame, int) */;
        doAssign(frameValue, expressionValue_);
        return;
    }

    private void executeVoid_double1(VirtualFrame frameValue, int state) {
        double expressionValue_;
        try {
            expressionValue_ = this.expression_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(frameValue, ex.getResult());
            return;
        }
        assert (state & 0b10) != 0 /* is-active doAssign(VirtualFrame, double) */;
        doAssign(frameValue, expressionValue_);
        return;
    }

    private void executeVoid_generic2(VirtualFrame frameValue, int state) {
        Object expressionValue_ = this.expression_.execute(frameValue);
        if ((state & 0b1) != 0 /* is-active doAssign(VirtualFrame, int) */ && expressionValue_ instanceof Integer) {
            int expressionValue__ = (int) expressionValue_;
            doAssign(frameValue, expressionValue__);
            return;
        }
        if ((state & 0b10) != 0 /* is-active doAssign(VirtualFrame, double) */ && expressionValue_ instanceof Double) {
            double expressionValue__ = (double) expressionValue_;
            doAssign(frameValue, expressionValue__);
            return;
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        executeAndSpecialize(frameValue, expressionValue_);
        return;
    }

    private void executeAndSpecialize(VirtualFrame frameValue, Object expressionValue) {
        int state = state_;
        if (expressionValue instanceof Integer) {
            int expressionValue_ = (int) expressionValue;
            this.state_ = state = state | 0b1 /* add-active doAssign(VirtualFrame, int) */;
            doAssign(frameValue, expressionValue_);
            return;
        }
        if (expressionValue instanceof Double) {
            double expressionValue_ = (double) expressionValue;
            this.state_ = state = state | 0b10 /* add-active doAssign(VirtualFrame, double) */;
            doAssign(frameValue, expressionValue_);
            return;
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.expression_}, expressionValue);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if ((state & (state - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    public static MJRemAssignStatementNode create(String varName, MJExpressionNode expression) {
        return new MJRemAssignStatementNodeGen(varName, expression);
    }

}
