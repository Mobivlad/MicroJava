// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.NodeCost;
import ukr.lpu.cs.mj.nodes.statements.MJBlockNode;
import ukr.lpu.cs.mj.nodes.statements.MJStatementNode;

@GeneratedBy(MJBlockNode.class)
public final class MJBlockNodeGen extends MJBlockNode {

    private MJBlockNodeGen(MJStatementNode[] nodes) {
        super(nodes);
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        startBlock(frameValue);
        return;
    }

    @Override
    public NodeCost getCost() {
        return NodeCost.MONOMORPHIC;
    }

    public static MJBlockNode create(MJStatementNode[] nodes) {
        return new MJBlockNodeGen(nodes);
    }

}
