// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.NodeCost;
import ukr.lpu.cs.mj.nodes.expressions.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.statements.MJStatementNode;
import ukr.lpu.cs.mj.nodes.statements.MJWhileStatement;

@GeneratedBy(MJWhileStatement.class)
public final class MJWhileStatementNodeGen extends MJWhileStatement {

    private MJWhileStatementNodeGen(MJExpressionNode conditionNode, MJStatementNode blockNode) {
        super(conditionNode, blockNode);
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        doLoop(frameValue);
        return;
    }

    @Override
    public NodeCost getCost() {
        return NodeCost.MONOMORPHIC;
    }

    public static MJWhileStatement create(MJExpressionNode conditionNode, MJStatementNode blockNode) {
        return new MJWhileStatementNodeGen(conditionNode, blockNode);
    }

}
