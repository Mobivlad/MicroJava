// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.expressions.functions;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.expressions.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.expressions.functions.MJFindExpressionNode;

@GeneratedBy(MJFindExpressionNode.class)
public final class MJFindExpressionNodeGen extends MJFindExpressionNode {

    @Child private MJExpressionNode op1_;
    @Child private MJExpressionNode op2_;
    @CompilationFinal private int state_;

    private MJFindExpressionNodeGen(MJExpressionNode op1, MJExpressionNode op2) {
        this.op1_ = op1;
        this.op2_ = op2;
    }

    @Override
    public Object execute(VirtualFrame frameValue) {
        int state = state_;
        Object op1Value_ = this.op1_.execute(frameValue);
        if ((state & 0b101) == 0 /* only-active find(String, int) */ && state != 0  /* is-not find(String, String) && find(String, int) && find(String, double) */) {
            return execute_int0(frameValue, state, op1Value_);
        } else if ((state & 0b11) == 0 /* only-active find(String, double) */ && state != 0  /* is-not find(String, String) && find(String, int) && find(String, double) */) {
            return execute_double1(frameValue, state, op1Value_);
        } else {
            return execute_generic2(frameValue, state, op1Value_);
        }
    }

    private Object execute_int0(VirtualFrame frameValue, int state, Object op1Value_) {
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b10) != 0 /* is-active find(String, int) */;
        if (op1Value_ instanceof String) {
            String op1Value__ = (String) op1Value_;
            return find(op1Value__, op2Value_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    private Object execute_double1(VirtualFrame frameValue, int state, Object op1Value_) {
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b100) != 0 /* is-active find(String, double) */;
        if (op1Value_ instanceof String) {
            String op1Value__ = (String) op1Value_;
            return find(op1Value__, op2Value_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    private Object execute_generic2(VirtualFrame frameValue, int state, Object op1Value_) {
        Object op2Value_ = this.op2_.execute(frameValue);
        if (state != 0 /* is-active find(String, String) || find(String, int) || find(String, double) */ && op1Value_ instanceof String) {
            String op1Value__ = (String) op1Value_;
            if ((state & 0b1) != 0 /* is-active find(String, String) */ && op2Value_ instanceof String) {
                String op2Value__ = (String) op2Value_;
                return find(op1Value__, op2Value__);
            }
            if ((state & 0b10) != 0 /* is-active find(String, int) */ && op2Value_ instanceof Integer) {
                int op2Value__ = (int) op2Value_;
                return find(op1Value__, op2Value__);
            }
            if ((state & 0b100) != 0 /* is-active find(String, double) */ && op2Value_ instanceof Double) {
                double op2Value__ = (double) op2Value_;
                return find(op1Value__, op2Value__);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    @Override
    public int executeInt(VirtualFrame frameValue) {
        int state = state_;
        Object op1Value_ = this.op1_.execute(frameValue);
        if ((state & 0b101) == 0 /* only-active find(String, int) */ && state != 0  /* is-not find(String, String) && find(String, int) && find(String, double) */) {
            return executeInt_int3(frameValue, state, op1Value_);
        } else if ((state & 0b11) == 0 /* only-active find(String, double) */ && state != 0  /* is-not find(String, String) && find(String, int) && find(String, double) */) {
            return executeInt_double4(frameValue, state, op1Value_);
        } else {
            return executeInt_generic5(frameValue, state, op1Value_);
        }
    }

    private int executeInt_int3(VirtualFrame frameValue, int state, Object op1Value_) {
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b10) != 0 /* is-active find(String, int) */;
        if (op1Value_ instanceof String) {
            String op1Value__ = (String) op1Value_;
            return find(op1Value__, op2Value_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    private int executeInt_double4(VirtualFrame frameValue, int state, Object op1Value_) {
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b100) != 0 /* is-active find(String, double) */;
        if (op1Value_ instanceof String) {
            String op1Value__ = (String) op1Value_;
            return find(op1Value__, op2Value_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    private int executeInt_generic5(VirtualFrame frameValue, int state, Object op1Value_) {
        Object op2Value_ = this.op2_.execute(frameValue);
        if (state != 0 /* is-active find(String, String) || find(String, int) || find(String, double) */ && op1Value_ instanceof String) {
            String op1Value__ = (String) op1Value_;
            if ((state & 0b1) != 0 /* is-active find(String, String) */ && op2Value_ instanceof String) {
                String op2Value__ = (String) op2Value_;
                return find(op1Value__, op2Value__);
            }
            if ((state & 0b10) != 0 /* is-active find(String, int) */ && op2Value_ instanceof Integer) {
                int op2Value__ = (int) op2Value_;
                return find(op1Value__, op2Value__);
            }
            if ((state & 0b100) != 0 /* is-active find(String, double) */ && op2Value_ instanceof Double) {
                double op2Value__ = (double) op2Value_;
                return find(op1Value__, op2Value__);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        executeInt(frameValue);
        return;
    }

    private int executeAndSpecialize(Object op1Value, Object op2Value) {
        int state = state_;
        if (op1Value instanceof String) {
            String op1Value_ = (String) op1Value;
            if (op2Value instanceof String) {
                String op2Value_ = (String) op2Value;
                this.state_ = state = state | 0b1 /* add-active find(String, String) */;
                return find(op1Value_, op2Value_);
            }
            if (op2Value instanceof Integer) {
                int op2Value_ = (int) op2Value;
                this.state_ = state = state | 0b10 /* add-active find(String, int) */;
                return find(op1Value_, op2Value_);
            }
            if (op2Value instanceof Double) {
                double op2Value_ = (double) op2Value;
                this.state_ = state = state | 0b100 /* add-active find(String, double) */;
                return find(op1Value_, op2Value_);
            }
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.op1_, this.op2_}, op1Value, op2Value);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if ((state & (state - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    public static MJFindExpressionNode create(MJExpressionNode op1, MJExpressionNode op2) {
        return new MJFindExpressionNodeGen(op1, op2);
    }

}
