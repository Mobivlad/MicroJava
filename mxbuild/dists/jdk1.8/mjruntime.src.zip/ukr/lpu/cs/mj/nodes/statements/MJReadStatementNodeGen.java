// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.NodeCost;
import ukr.lpu.cs.mj.nodes.statements.MJReadStatement;

@GeneratedBy(MJReadStatement.class)
public final class MJReadStatementNodeGen extends MJReadStatement {

    private MJReadStatementNodeGen(String varName) {
        super(varName);
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        read(frameValue);
        return;
    }

    @Override
    public NodeCost getCost() {
        return NodeCost.MONOMORPHIC;
    }

    public static MJReadStatement create(String varName) {
        return new MJReadStatementNodeGen(varName);
    }

}
