// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import ukr.lpu.cs.mj.nodes.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.statements.MJReadStatement;
import ukr.lpu.cs.mj.nodes.symbols.MJDoubleSymbolNode;
import ukr.lpu.cs.mj.nodes.symbols.MJIntSymbolNode;
import ukr.lpu.cs.mj.nodes.symbols.MJStringSymbolNode;

@GeneratedBy(MJReadStatement.class)
public final class MJReadStatementNodeGen extends MJReadStatement {

    @Child private MJExpressionNode op_;
    @CompilationFinal private int state_;

    private MJReadStatementNodeGen(MJExpressionNode op) {
        this.op_ = op;
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        int state = state_;
        Object opValue_ = this.op_.execute(frameValue);
        if ((state & 0b1) != 0 /* is-active read(MJIntSymbolNode) */ && opValue_ instanceof MJIntSymbolNode) {
            MJIntSymbolNode opValue__ = (MJIntSymbolNode) opValue_;
            read(opValue__);
            return;
        }
        if ((state & 0b10) != 0 /* is-active read(MJDoubleSymbolNode) */ && opValue_ instanceof MJDoubleSymbolNode) {
            MJDoubleSymbolNode opValue__ = (MJDoubleSymbolNode) opValue_;
            read(opValue__);
            return;
        }
        if ((state & 0b100) != 0 /* is-active read(MJStringSymbolNode) */ && opValue_ instanceof MJStringSymbolNode) {
            MJStringSymbolNode opValue__ = (MJStringSymbolNode) opValue_;
            read(opValue__);
            return;
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        executeAndSpecialize(opValue_);
        return;
    }

    private void executeAndSpecialize(Object opValue) {
        int state = state_;
        if (opValue instanceof MJIntSymbolNode) {
            MJIntSymbolNode opValue_ = (MJIntSymbolNode) opValue;
            this.state_ = state = state | 0b1 /* add-active read(MJIntSymbolNode) */;
            read(opValue_);
            return;
        }
        if (opValue instanceof MJDoubleSymbolNode) {
            MJDoubleSymbolNode opValue_ = (MJDoubleSymbolNode) opValue;
            this.state_ = state = state | 0b10 /* add-active read(MJDoubleSymbolNode) */;
            read(opValue_);
            return;
        }
        if (opValue instanceof MJStringSymbolNode) {
            MJStringSymbolNode opValue_ = (MJStringSymbolNode) opValue;
            this.state_ = state = state | 0b100 /* add-active read(MJStringSymbolNode) */;
            read(opValue_);
            return;
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.op_}, opValue);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if ((state & (state - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    public static MJReadStatement create(MJExpressionNode op) {
        return new MJReadStatementNodeGen(op);
    }

}
