// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import java.util.List;
import ukr.lpu.cs.mj.nodes.expressions.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.statements.MJPrintNode;

@GeneratedBy(MJPrintNode.class)
public final class MJPrintNodeGen extends MJPrintNode {

    @Child private MJExpressionNode child0_;
    @CompilationFinal private int state_;

    private MJPrintNodeGen(List<MJExpressionNode> list, MJExpressionNode child0) {
        super(list);
        this.child0_ = child0;
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        int state = state_;
        if ((state & 0b101) == 0 /* only-active print(int) */ && state != 0  /* is-not print(VirtualFrame, String) && print(int) && print(double) */) {
            executeVoid_int0(frameValue, state);
            return;
        } else if ((state & 0b11) == 0 /* only-active print(double) */ && state != 0  /* is-not print(VirtualFrame, String) && print(int) && print(double) */) {
            executeVoid_double1(frameValue, state);
            return;
        } else {
            executeVoid_generic2(frameValue, state);
            return;
        }
    }

    private void executeVoid_int0(VirtualFrame frameValue, int state) {
        int child0Value_;
        try {
            child0Value_ = this.child0_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(frameValue, ex.getResult());
            return;
        }
        assert (state & 0b10) != 0 /* is-active print(int) */;
        print(child0Value_);
        return;
    }

    private void executeVoid_double1(VirtualFrame frameValue, int state) {
        double child0Value_;
        try {
            child0Value_ = this.child0_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(frameValue, ex.getResult());
            return;
        }
        assert (state & 0b100) != 0 /* is-active print(double) */;
        print(child0Value_);
        return;
    }

    private void executeVoid_generic2(VirtualFrame frameValue, int state) {
        Object child0Value_ = this.child0_.execute(frameValue);
        if ((state & 0b1) != 0 /* is-active print(VirtualFrame, String) */ && child0Value_ instanceof String) {
            String child0Value__ = (String) child0Value_;
            print(frameValue, child0Value__);
            return;
        }
        if ((state & 0b10) != 0 /* is-active print(int) */ && child0Value_ instanceof Integer) {
            int child0Value__ = (int) child0Value_;
            print(child0Value__);
            return;
        }
        if ((state & 0b100) != 0 /* is-active print(double) */ && child0Value_ instanceof Double) {
            double child0Value__ = (double) child0Value_;
            print(child0Value__);
            return;
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        executeAndSpecialize(frameValue, child0Value_);
        return;
    }

    private void executeAndSpecialize(VirtualFrame frameValue, Object child0Value) {
        int state = state_;
        if (child0Value instanceof String) {
            String child0Value_ = (String) child0Value;
            this.state_ = state = state | 0b1 /* add-active print(VirtualFrame, String) */;
            print(frameValue, child0Value_);
            return;
        }
        if (child0Value instanceof Integer) {
            int child0Value_ = (int) child0Value;
            this.state_ = state = state | 0b10 /* add-active print(int) */;
            print(child0Value_);
            return;
        }
        if (child0Value instanceof Double) {
            double child0Value_ = (double) child0Value;
            this.state_ = state = state | 0b100 /* add-active print(double) */;
            print(child0Value_);
            return;
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.child0_}, child0Value);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if ((state & (state - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    public static MJPrintNode create(List<MJExpressionNode> list, MJExpressionNode child0) {
        return new MJPrintNodeGen(list, child0);
    }

}
