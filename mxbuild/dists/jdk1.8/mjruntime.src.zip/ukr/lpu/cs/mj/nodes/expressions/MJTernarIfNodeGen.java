// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.expressions;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.expressions.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.expressions.MJTernarIfNode;

@GeneratedBy(MJTernarIfNode.class)
public final class MJTernarIfNodeGen extends MJTernarIfNode {

    @Child private MJExpressionNode op1_;
    @Child private MJExpressionNode op2_;
    @Child private MJExpressionNode op3_;
    @CompilationFinal private int state_;

    private MJTernarIfNodeGen(MJExpressionNode op1, MJExpressionNode op2, MJExpressionNode op3) {
        this.op1_ = op1;
        this.op2_ = op2;
        this.op3_ = op3;
    }

    @Override
    public Object execute(VirtualFrame frameValue) {
        int state = state_;
        boolean op1Value_;
        try {
            op1Value_ = this.op1_.executeBoolean(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            Object op3Value = this.op3_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value, op3Value);
        }
        if ((state & 0b11110) == 0 /* only-active f(boolean, int, int) */ && state != 0  /* is-not f(boolean, int, int) && f(boolean, String, String) && f(boolean, int, double) && f(boolean, double, int) && f(boolean, double, double) */) {
            return execute_int_int0(frameValue, state, op1Value_);
        } else if ((state & 0b11011) == 0 /* only-active f(boolean, int, double) */ && state != 0  /* is-not f(boolean, int, int) && f(boolean, String, String) && f(boolean, int, double) && f(boolean, double, int) && f(boolean, double, double) */) {
            return execute_int_double1(frameValue, state, op1Value_);
        } else if ((state & 0b10111) == 0 /* only-active f(boolean, double, int) */ && state != 0  /* is-not f(boolean, int, int) && f(boolean, String, String) && f(boolean, int, double) && f(boolean, double, int) && f(boolean, double, double) */) {
            return execute_double_int2(frameValue, state, op1Value_);
        } else if ((state & 0b1111) == 0 /* only-active f(boolean, double, double) */ && state != 0  /* is-not f(boolean, int, int) && f(boolean, String, String) && f(boolean, int, double) && f(boolean, double, int) && f(boolean, double, double) */) {
            return execute_double_double3(frameValue, state, op1Value_);
        } else {
            return execute_generic4(frameValue, state, op1Value_);
        }
    }

    private Object execute_int_int0(VirtualFrame frameValue, int state, boolean op1Value_) {
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op3Value = this.op3_.execute(frameValue);
            return executeAndSpecialize(op1Value_, ex.getResult(), op3Value);
        }
        int op3Value_;
        try {
            op3Value_ = this.op3_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, op2Value_, ex.getResult());
        }
        assert (state & 0b1) != 0 /* is-active f(boolean, int, int) */;
        return f(op1Value_, op2Value_, op3Value_);
    }

    private Object execute_int_double1(VirtualFrame frameValue, int state, boolean op1Value_) {
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op3Value = this.op3_.execute(frameValue);
            return executeAndSpecialize(op1Value_, ex.getResult(), op3Value);
        }
        double op3Value_;
        try {
            op3Value_ = this.op3_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, op2Value_, ex.getResult());
        }
        assert (state & 0b100) != 0 /* is-active f(boolean, int, double) */;
        return f(op1Value_, op2Value_, op3Value_);
    }

    private Object execute_double_int2(VirtualFrame frameValue, int state, boolean op1Value_) {
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op3Value = this.op3_.execute(frameValue);
            return executeAndSpecialize(op1Value_, ex.getResult(), op3Value);
        }
        int op3Value_;
        try {
            op3Value_ = this.op3_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, op2Value_, ex.getResult());
        }
        assert (state & 0b1000) != 0 /* is-active f(boolean, double, int) */;
        return f(op1Value_, op2Value_, op3Value_);
    }

    private Object execute_double_double3(VirtualFrame frameValue, int state, boolean op1Value_) {
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op3Value = this.op3_.execute(frameValue);
            return executeAndSpecialize(op1Value_, ex.getResult(), op3Value);
        }
        double op3Value_;
        try {
            op3Value_ = this.op3_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, op2Value_, ex.getResult());
        }
        assert (state & 0b10000) != 0 /* is-active f(boolean, double, double) */;
        return f(op1Value_, op2Value_, op3Value_);
    }

    private Object execute_generic4(VirtualFrame frameValue, int state, boolean op1Value_) {
        Object op2Value_ = this.op2_.execute(frameValue);
        Object op3Value_ = this.op3_.execute(frameValue);
        if ((state & 0b1) != 0 /* is-active f(boolean, int, int) */ && op2Value_ instanceof Integer) {
            int op2Value__ = (int) op2Value_;
            if (op3Value_ instanceof Integer) {
                int op3Value__ = (int) op3Value_;
                return f(op1Value_, op2Value__, op3Value__);
            }
        }
        if ((state & 0b10) != 0 /* is-active f(boolean, String, String) */ && op2Value_ instanceof String) {
            String op2Value__ = (String) op2Value_;
            if (op3Value_ instanceof String) {
                String op3Value__ = (String) op3Value_;
                return f(op1Value_, op2Value__, op3Value__);
            }
        }
        if ((state & 0b100) != 0 /* is-active f(boolean, int, double) */ && op2Value_ instanceof Integer) {
            int op2Value__ = (int) op2Value_;
            if (op3Value_ instanceof Double) {
                double op3Value__ = (double) op3Value_;
                return f(op1Value_, op2Value__, op3Value__);
            }
        }
        if ((state & 0b11000) != 0 /* is-active f(boolean, double, int) || f(boolean, double, double) */ && op2Value_ instanceof Double) {
            double op2Value__ = (double) op2Value_;
            if ((state & 0b1000) != 0 /* is-active f(boolean, double, int) */ && op3Value_ instanceof Integer) {
                int op3Value__ = (int) op3Value_;
                return f(op1Value_, op2Value__, op3Value__);
            }
            if ((state & 0b10000) != 0 /* is-active f(boolean, double, double) */ && op3Value_ instanceof Double) {
                double op3Value__ = (double) op3Value_;
                return f(op1Value_, op2Value__, op3Value__);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_, op3Value_);
    }

    @Override
    public double executeDouble(VirtualFrame frameValue) throws UnexpectedResultException {
        int state = state_;
        boolean op1Value_;
        try {
            op1Value_ = this.op1_.executeBoolean(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            Object op3Value = this.op3_.execute(frameValue);
            return expectDouble(executeAndSpecialize(ex.getResult(), op2Value, op3Value));
        }
        if ((state & 0b11000) == 0 /* only-active f(boolean, int, double) */ && (state & 0b11100) != 0  /* is-not f(boolean, int, double) && f(boolean, double, int) && f(boolean, double, double) */) {
            return executeDouble_int_double5(frameValue, state, op1Value_);
        } else if ((state & 0b10100) == 0 /* only-active f(boolean, double, int) */ && (state & 0b11100) != 0  /* is-not f(boolean, int, double) && f(boolean, double, int) && f(boolean, double, double) */) {
            return executeDouble_double_int6(frameValue, state, op1Value_);
        } else if ((state & 0b1100) == 0 /* only-active f(boolean, double, double) */ && (state & 0b11100) != 0  /* is-not f(boolean, int, double) && f(boolean, double, int) && f(boolean, double, double) */) {
            return executeDouble_double_double7(frameValue, state, op1Value_);
        } else {
            return executeDouble_generic8(frameValue, state, op1Value_);
        }
    }

    private double executeDouble_int_double5(VirtualFrame frameValue, int state, boolean op1Value_) throws UnexpectedResultException {
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op3Value = this.op3_.execute(frameValue);
            return expectDouble(executeAndSpecialize(op1Value_, ex.getResult(), op3Value));
        }
        double op3Value_;
        try {
            op3Value_ = this.op3_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return expectDouble(executeAndSpecialize(op1Value_, op2Value_, ex.getResult()));
        }
        assert (state & 0b100) != 0 /* is-active f(boolean, int, double) */;
        return f(op1Value_, op2Value_, op3Value_);
    }

    private double executeDouble_double_int6(VirtualFrame frameValue, int state, boolean op1Value_) throws UnexpectedResultException {
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op3Value = this.op3_.execute(frameValue);
            return expectDouble(executeAndSpecialize(op1Value_, ex.getResult(), op3Value));
        }
        int op3Value_;
        try {
            op3Value_ = this.op3_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return expectDouble(executeAndSpecialize(op1Value_, op2Value_, ex.getResult()));
        }
        assert (state & 0b1000) != 0 /* is-active f(boolean, double, int) */;
        return f(op1Value_, op2Value_, op3Value_);
    }

    private double executeDouble_double_double7(VirtualFrame frameValue, int state, boolean op1Value_) throws UnexpectedResultException {
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op3Value = this.op3_.execute(frameValue);
            return expectDouble(executeAndSpecialize(op1Value_, ex.getResult(), op3Value));
        }
        double op3Value_;
        try {
            op3Value_ = this.op3_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return expectDouble(executeAndSpecialize(op1Value_, op2Value_, ex.getResult()));
        }
        assert (state & 0b10000) != 0 /* is-active f(boolean, double, double) */;
        return f(op1Value_, op2Value_, op3Value_);
    }

    private double executeDouble_generic8(VirtualFrame frameValue, int state, boolean op1Value_) throws UnexpectedResultException {
        Object op2Value_ = this.op2_.execute(frameValue);
        Object op3Value_ = this.op3_.execute(frameValue);
        if ((state & 0b100) != 0 /* is-active f(boolean, int, double) */ && op2Value_ instanceof Integer) {
            int op2Value__ = (int) op2Value_;
            if (op3Value_ instanceof Double) {
                double op3Value__ = (double) op3Value_;
                return f(op1Value_, op2Value__, op3Value__);
            }
        }
        if ((state & 0b11000) != 0 /* is-active f(boolean, double, int) || f(boolean, double, double) */ && op2Value_ instanceof Double) {
            double op2Value__ = (double) op2Value_;
            if ((state & 0b1000) != 0 /* is-active f(boolean, double, int) */ && op3Value_ instanceof Integer) {
                int op3Value__ = (int) op3Value_;
                return f(op1Value_, op2Value__, op3Value__);
            }
            if ((state & 0b10000) != 0 /* is-active f(boolean, double, double) */ && op3Value_ instanceof Double) {
                double op3Value__ = (double) op3Value_;
                return f(op1Value_, op2Value__, op3Value__);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return expectDouble(executeAndSpecialize(op1Value_, op2Value_, op3Value_));
    }

    @Override
    public int executeInt(VirtualFrame frameValue) throws UnexpectedResultException {
        int state = state_;
        boolean op1Value_;
        try {
            op1Value_ = this.op1_.executeBoolean(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            Object op3Value = this.op3_.execute(frameValue);
            return expectInteger(executeAndSpecialize(ex.getResult(), op2Value, op3Value));
        }
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op3Value = this.op3_.execute(frameValue);
            return expectInteger(executeAndSpecialize(op1Value_, ex.getResult(), op3Value));
        }
        int op3Value_;
        try {
            op3Value_ = this.op3_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return expectInteger(executeAndSpecialize(op1Value_, op2Value_, ex.getResult()));
        }
        if ((state & 0b1) != 0 /* is-active f(boolean, int, int) */) {
            return f(op1Value_, op2Value_, op3Value_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return expectInteger(executeAndSpecialize(op1Value_, op2Value_, op3Value_));
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        int state = state_;
        try {
            if ((state & 0b11110) == 0 /* only-active f(boolean, int, int) */ && state != 0  /* is-not f(boolean, int, int) && f(boolean, String, String) && f(boolean, int, double) && f(boolean, double, int) && f(boolean, double, double) */) {
                executeInt(frameValue);
                return;
            } else if ((state & 0b11) == 0 /* only-active f(boolean, int, double) && f(boolean, double, int) && f(boolean, double, double) */ && state != 0  /* is-not f(boolean, int, int) && f(boolean, String, String) && f(boolean, int, double) && f(boolean, double, int) && f(boolean, double, double) */) {
                executeDouble(frameValue);
                return;
            }
            execute(frameValue);
            return;
        } catch (UnexpectedResultException ex) {
            return;
        }
    }

    private Object executeAndSpecialize(Object op1Value, Object op2Value, Object op3Value) {
        int state = state_;
        if (op1Value instanceof Boolean) {
            boolean op1Value_ = (boolean) op1Value;
            if (op2Value instanceof Integer) {
                int op2Value_ = (int) op2Value;
                if (op3Value instanceof Integer) {
                    int op3Value_ = (int) op3Value;
                    this.state_ = state = state | 0b1 /* add-active f(boolean, int, int) */;
                    return f(op1Value_, op2Value_, op3Value_);
                }
            }
            if (op2Value instanceof String) {
                String op2Value_ = (String) op2Value;
                if (op3Value instanceof String) {
                    String op3Value_ = (String) op3Value;
                    this.state_ = state = state | 0b10 /* add-active f(boolean, String, String) */;
                    return f(op1Value_, op2Value_, op3Value_);
                }
            }
            if (op2Value instanceof Integer) {
                int op2Value_ = (int) op2Value;
                if (op3Value instanceof Double) {
                    double op3Value_ = (double) op3Value;
                    this.state_ = state = state | 0b100 /* add-active f(boolean, int, double) */;
                    return f(op1Value_, op2Value_, op3Value_);
                }
            }
            if (op2Value instanceof Double) {
                double op2Value_ = (double) op2Value;
                if (op3Value instanceof Integer) {
                    int op3Value_ = (int) op3Value;
                    this.state_ = state = state | 0b1000 /* add-active f(boolean, double, int) */;
                    return f(op1Value_, op2Value_, op3Value_);
                }
                if (op3Value instanceof Double) {
                    double op3Value_ = (double) op3Value;
                    this.state_ = state = state | 0b10000 /* add-active f(boolean, double, double) */;
                    return f(op1Value_, op2Value_, op3Value_);
                }
            }
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.op1_, this.op2_, this.op3_}, op1Value, op2Value, op3Value);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if ((state & (state - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    private static double expectDouble(Object value) throws UnexpectedResultException {
        if (value instanceof Double) {
            return (double) value;
        }
        throw new UnexpectedResultException(value);
    }

    private static int expectInteger(Object value) throws UnexpectedResultException {
        if (value instanceof Integer) {
            return (int) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static MJTernarIfNode create(MJExpressionNode op1, MJExpressionNode op2, MJExpressionNode op3) {
        return new MJTernarIfNodeGen(op1, op2, op3);
    }

}
