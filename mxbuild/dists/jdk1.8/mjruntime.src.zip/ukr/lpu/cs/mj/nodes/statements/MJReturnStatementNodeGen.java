// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.NodeCost;
import ukr.lpu.cs.mj.nodes.expressions.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.statements.MJReturnStatement;

@GeneratedBy(MJReturnStatement.class)
public final class MJReturnStatementNodeGen extends MJReturnStatement {

    private MJReturnStatementNodeGen(MJExpressionNode valueNode) {
        super(valueNode);
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        doReturn(frameValue);
        return;
    }

    @Override
    public NodeCost getCost() {
        return NodeCost.MONOMORPHIC;
    }

    public static MJReturnStatement create(MJExpressionNode valueNode) {
        return new MJReturnStatementNodeGen(valueNode);
    }

}
