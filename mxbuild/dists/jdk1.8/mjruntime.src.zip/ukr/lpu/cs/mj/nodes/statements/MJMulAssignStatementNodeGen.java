// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.MJSymbolNode;
import ukr.lpu.cs.mj.nodes.statements.MJMulAssignStatementNode;

@GeneratedBy(MJMulAssignStatementNode.class)
public final class MJMulAssignStatementNodeGen extends MJMulAssignStatementNode {

    @Child private MJExpressionNode symbol_;
    @Child private MJExpressionNode expression1_;
    @Child private MJExpressionNode expression2_;
    @CompilationFinal private int state_;

    private MJMulAssignStatementNodeGen(MJExpressionNode symbol, MJExpressionNode expression1, MJExpressionNode expression2) {
        this.symbol_ = symbol;
        this.expression1_ = expression1;
        this.expression2_ = expression2;
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        int state = state_;
        Object symbolValue_ = this.symbol_.execute(frameValue);
        if ((state & 0b10) == 0 /* only-active doAssign(MJSymbolNode, int, int) */ && state != 0  /* is-not doAssign(MJSymbolNode, int, int) && doAssign(MJSymbolNode, double, double) */) {
            executeVoid_int_int0(frameValue, state, symbolValue_);
            return;
        } else if ((state & 0b1) == 0 /* only-active doAssign(MJSymbolNode, double, double) */ && state != 0  /* is-not doAssign(MJSymbolNode, int, int) && doAssign(MJSymbolNode, double, double) */) {
            executeVoid_double_double1(frameValue, state, symbolValue_);
            return;
        } else {
            executeVoid_generic2(frameValue, state, symbolValue_);
            return;
        }
    }

    private void executeVoid_int_int0(VirtualFrame frameValue, int state, Object symbolValue_) {
        int expression1Value_;
        try {
            expression1Value_ = this.expression1_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object expression2Value = this.expression2_.execute(frameValue);
            executeAndSpecialize(symbolValue_, ex.getResult(), expression2Value);
            return;
        }
        int expression2Value_;
        try {
            expression2Value_ = this.expression2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(symbolValue_, expression1Value_, ex.getResult());
            return;
        }
        assert (state & 0b1) != 0 /* is-active doAssign(MJSymbolNode, int, int) */;
        if (symbolValue_ instanceof MJSymbolNode) {
            MJSymbolNode symbolValue__ = (MJSymbolNode) symbolValue_;
            doAssign(symbolValue__, expression1Value_, expression2Value_);
            return;
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        executeAndSpecialize(symbolValue_, expression1Value_, expression2Value_);
        return;
    }

    private void executeVoid_double_double1(VirtualFrame frameValue, int state, Object symbolValue_) {
        double expression1Value_;
        try {
            expression1Value_ = this.expression1_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object expression2Value = this.expression2_.execute(frameValue);
            executeAndSpecialize(symbolValue_, ex.getResult(), expression2Value);
            return;
        }
        double expression2Value_;
        try {
            expression2Value_ = this.expression2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(symbolValue_, expression1Value_, ex.getResult());
            return;
        }
        assert (state & 0b10) != 0 /* is-active doAssign(MJSymbolNode, double, double) */;
        if (symbolValue_ instanceof MJSymbolNode) {
            MJSymbolNode symbolValue__ = (MJSymbolNode) symbolValue_;
            doAssign(symbolValue__, expression1Value_, expression2Value_);
            return;
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        executeAndSpecialize(symbolValue_, expression1Value_, expression2Value_);
        return;
    }

    private void executeVoid_generic2(VirtualFrame frameValue, int state, Object symbolValue_) {
        Object expression1Value_ = this.expression1_.execute(frameValue);
        Object expression2Value_ = this.expression2_.execute(frameValue);
        if (state != 0 /* is-active doAssign(MJSymbolNode, int, int) || doAssign(MJSymbolNode, double, double) */ && symbolValue_ instanceof MJSymbolNode) {
            MJSymbolNode symbolValue__ = (MJSymbolNode) symbolValue_;
            if ((state & 0b1) != 0 /* is-active doAssign(MJSymbolNode, int, int) */ && expression1Value_ instanceof Integer) {
                int expression1Value__ = (int) expression1Value_;
                if (expression2Value_ instanceof Integer) {
                    int expression2Value__ = (int) expression2Value_;
                    doAssign(symbolValue__, expression1Value__, expression2Value__);
                    return;
                }
            }
            if ((state & 0b10) != 0 /* is-active doAssign(MJSymbolNode, double, double) */ && expression1Value_ instanceof Double) {
                double expression1Value__ = (double) expression1Value_;
                if (expression2Value_ instanceof Double) {
                    double expression2Value__ = (double) expression2Value_;
                    doAssign(symbolValue__, expression1Value__, expression2Value__);
                    return;
                }
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        executeAndSpecialize(symbolValue_, expression1Value_, expression2Value_);
        return;
    }

    private void executeAndSpecialize(Object symbolValue, Object expression1Value, Object expression2Value) {
        int state = state_;
        if (symbolValue instanceof MJSymbolNode) {
            MJSymbolNode symbolValue_ = (MJSymbolNode) symbolValue;
            if (expression1Value instanceof Integer) {
                int expression1Value_ = (int) expression1Value;
                if (expression2Value instanceof Integer) {
                    int expression2Value_ = (int) expression2Value;
                    this.state_ = state = state | 0b1 /* add-active doAssign(MJSymbolNode, int, int) */;
                    doAssign(symbolValue_, expression1Value_, expression2Value_);
                    return;
                }
            }
            if (expression1Value instanceof Double) {
                double expression1Value_ = (double) expression1Value;
                if (expression2Value instanceof Double) {
                    double expression2Value_ = (double) expression2Value;
                    this.state_ = state = state | 0b10 /* add-active doAssign(MJSymbolNode, double, double) */;
                    doAssign(symbolValue_, expression1Value_, expression2Value_);
                    return;
                }
            }
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.symbol_, this.expression1_, this.expression2_}, symbolValue, expression1Value, expression2Value);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if ((state & (state - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    public static MJMulAssignStatementNode create(MJExpressionNode symbol, MJExpressionNode expression1, MJExpressionNode expression2) {
        return new MJMulAssignStatementNodeGen(symbol, expression1, expression2);
    }

}
