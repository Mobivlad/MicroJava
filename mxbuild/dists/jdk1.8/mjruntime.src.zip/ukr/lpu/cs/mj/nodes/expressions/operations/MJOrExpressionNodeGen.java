// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.expressions.operations;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.expressions.operations.MJOrExpression;

@GeneratedBy(MJOrExpression.class)
public final class MJOrExpressionNodeGen extends MJOrExpression {

    @Child private MJExpressionNode op1_;
    @Child private MJExpressionNode op2_;
    @CompilationFinal private int state_;

    private MJOrExpressionNodeGen(MJExpressionNode op1, MJExpressionNode op2) {
        this.op1_ = op1;
        this.op2_ = op2;
    }

    @Override
    public Object execute(VirtualFrame frameValue) {
        int state = state_;
        boolean op1Value_;
        try {
            op1Value_ = this.op1_.executeBoolean(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        boolean op2Value_;
        try {
            op2Value_ = this.op2_.executeBoolean(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        if (state != 0 /* is-active or(boolean, boolean) */) {
            return or(op1Value_, op2Value_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    @Override
    public boolean executeBoolean(VirtualFrame frameValue) {
        int state = state_;
        boolean op1Value_;
        try {
            op1Value_ = this.op1_.executeBoolean(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        boolean op2Value_;
        try {
            op2Value_ = this.op2_.executeBoolean(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        if (state != 0 /* is-active or(boolean, boolean) */) {
            return or(op1Value_, op2Value_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        executeBoolean(frameValue);
        return;
    }

    private boolean executeAndSpecialize(Object op1Value, Object op2Value) {
        int state = state_;
        if (op1Value instanceof Boolean) {
            boolean op1Value_ = (boolean) op1Value;
            if (op2Value instanceof Boolean) {
                boolean op2Value_ = (boolean) op2Value;
                this.state_ = state = state | 0b1 /* add-active or(boolean, boolean) */;
                return or(op1Value_, op2Value_);
            }
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.op1_, this.op2_}, op1Value, op2Value);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else {
            return NodeCost.MONOMORPHIC;
        }
    }

    public static MJOrExpression create(MJExpressionNode op1, MJExpressionNode op2) {
        return new MJOrExpressionNodeGen(op1, op2);
    }

}
