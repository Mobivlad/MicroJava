// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.NodeCost;
import ukr.lpu.cs.mj.nodes.statements.MJDecrementStatement;

@GeneratedBy(MJDecrementStatement.class)
public final class MJDecrementStatementNodeGen extends MJDecrementStatement {

    private MJDecrementStatementNodeGen(String varName) {
        super(varName);
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        doInc(frameValue);
        return;
    }

    @Override
    public NodeCost getCost() {
        return NodeCost.MONOMORPHIC;
    }

    public static MJDecrementStatement create(String varName) {
        return new MJDecrementStatementNodeGen(varName);
    }

}
