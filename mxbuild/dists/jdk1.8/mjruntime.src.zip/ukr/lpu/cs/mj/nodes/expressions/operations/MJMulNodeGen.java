// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.expressions.operations;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.expressions.operations.MJMulNode;

@GeneratedBy(MJMulNode.class)
public final class MJMulNodeGen extends MJMulNode {

    @Child private MJExpressionNode op1_;
    @Child private MJExpressionNode op2_;
    @CompilationFinal private int state_;

    private MJMulNodeGen(MJExpressionNode op1, MJExpressionNode op2) {
        this.op1_ = op1;
        this.op2_ = op2;
    }

    @Override
    public Object execute(VirtualFrame frameValue) {
        int state = state_;
        if ((state & 0b11110) == 0 /* only-active mul(int, int) */ && state != 0  /* is-not mul(int, int) && mul(double, double) && mul(int, double) && mul(double, int) && mul(String, int) */) {
            return execute_int_int0(frameValue, state);
        } else if ((state & 0b11101) == 0 /* only-active mul(double, double) */ && state != 0  /* is-not mul(int, int) && mul(double, double) && mul(int, double) && mul(double, int) && mul(String, int) */) {
            return execute_double_double1(frameValue, state);
        } else if ((state & 0b11011) == 0 /* only-active mul(int, double) */ && state != 0  /* is-not mul(int, int) && mul(double, double) && mul(int, double) && mul(double, int) && mul(String, int) */) {
            return execute_int_double2(frameValue, state);
        } else if ((state & 0b10111) == 0 /* only-active mul(double, int) */ && state != 0  /* is-not mul(int, int) && mul(double, double) && mul(int, double) && mul(double, int) && mul(String, int) */) {
            return execute_double_int3(frameValue, state);
        } else if ((state & 0b1111) == 0 /* only-active mul(String, int) */ && state != 0  /* is-not mul(int, int) && mul(double, double) && mul(int, double) && mul(double, int) && mul(String, int) */) {
            return execute_int4(frameValue, state);
        } else {
            return execute_generic5(frameValue, state);
        }
    }

    private Object execute_int_int0(VirtualFrame frameValue, int state) {
        int op1Value_;
        try {
            op1Value_ = this.op1_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b1) != 0 /* is-active mul(int, int) */;
        return mul(op1Value_, op2Value_);
    }

    private Object execute_double_double1(VirtualFrame frameValue, int state) {
        double op1Value_;
        try {
            op1Value_ = this.op1_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b10) != 0 /* is-active mul(double, double) */;
        return mul(op1Value_, op2Value_);
    }

    private Object execute_int_double2(VirtualFrame frameValue, int state) {
        int op1Value_;
        try {
            op1Value_ = this.op1_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b100) != 0 /* is-active mul(int, double) */;
        return mul(op1Value_, op2Value_);
    }

    private Object execute_double_int3(VirtualFrame frameValue, int state) {
        double op1Value_;
        try {
            op1Value_ = this.op1_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b1000) != 0 /* is-active mul(double, int) */;
        return mul(op1Value_, op2Value_);
    }

    private Object execute_int4(VirtualFrame frameValue, int state) {
        Object op1Value_ = this.op1_.execute(frameValue);
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b10000) != 0 /* is-active mul(String, int) */;
        if (op1Value_ instanceof String) {
            String op1Value__ = (String) op1Value_;
            return mul(op1Value__, op2Value_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    private Object execute_generic5(VirtualFrame frameValue, int state) {
        Object op1Value_ = this.op1_.execute(frameValue);
        Object op2Value_ = this.op2_.execute(frameValue);
        if ((state & 0b1) != 0 /* is-active mul(int, int) */ && op1Value_ instanceof Integer) {
            int op1Value__ = (int) op1Value_;
            if (op2Value_ instanceof Integer) {
                int op2Value__ = (int) op2Value_;
                return mul(op1Value__, op2Value__);
            }
        }
        if ((state & 0b110) != 0 /* is-active mul(double, double) || mul(int, double) */ && op2Value_ instanceof Double) {
            double op2Value__ = (double) op2Value_;
            if ((state & 0b10) != 0 /* is-active mul(double, double) */ && op1Value_ instanceof Double) {
                double op1Value__ = (double) op1Value_;
                return mul(op1Value__, op2Value__);
            }
            if ((state & 0b100) != 0 /* is-active mul(int, double) */ && op1Value_ instanceof Integer) {
                int op1Value__ = (int) op1Value_;
                return mul(op1Value__, op2Value__);
            }
        }
        if ((state & 0b11000) != 0 /* is-active mul(double, int) || mul(String, int) */ && op2Value_ instanceof Integer) {
            int op2Value__ = (int) op2Value_;
            if ((state & 0b1000) != 0 /* is-active mul(double, int) */ && op1Value_ instanceof Double) {
                double op1Value__ = (double) op1Value_;
                return mul(op1Value__, op2Value__);
            }
            if ((state & 0b10000) != 0 /* is-active mul(String, int) */ && op1Value_ instanceof String) {
                String op1Value__ = (String) op1Value_;
                return mul(op1Value__, op2Value__);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    @Override
    public double executeDouble(VirtualFrame frameValue) throws UnexpectedResultException {
        int state = state_;
        if ((state & 0b1100) == 0 /* only-active mul(double, double) */ && (state & 0b1110) != 0  /* is-not mul(double, double) && mul(int, double) && mul(double, int) */) {
            return executeDouble_double_double6(frameValue, state);
        } else if ((state & 0b1010) == 0 /* only-active mul(int, double) */ && (state & 0b1110) != 0  /* is-not mul(double, double) && mul(int, double) && mul(double, int) */) {
            return executeDouble_int_double7(frameValue, state);
        } else if ((state & 0b110) == 0 /* only-active mul(double, int) */ && (state & 0b1110) != 0  /* is-not mul(double, double) && mul(int, double) && mul(double, int) */) {
            return executeDouble_double_int8(frameValue, state);
        } else {
            return executeDouble_generic9(frameValue, state);
        }
    }

    private double executeDouble_double_double6(VirtualFrame frameValue, int state) throws UnexpectedResultException {
        double op1Value_;
        try {
            op1Value_ = this.op1_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return expectDouble(executeAndSpecialize(ex.getResult(), op2Value));
        }
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return expectDouble(executeAndSpecialize(op1Value_, ex.getResult()));
        }
        assert (state & 0b10) != 0 /* is-active mul(double, double) */;
        return mul(op1Value_, op2Value_);
    }

    private double executeDouble_int_double7(VirtualFrame frameValue, int state) throws UnexpectedResultException {
        int op1Value_;
        try {
            op1Value_ = this.op1_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return expectDouble(executeAndSpecialize(ex.getResult(), op2Value));
        }
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return expectDouble(executeAndSpecialize(op1Value_, ex.getResult()));
        }
        assert (state & 0b100) != 0 /* is-active mul(int, double) */;
        return mul(op1Value_, op2Value_);
    }

    private double executeDouble_double_int8(VirtualFrame frameValue, int state) throws UnexpectedResultException {
        double op1Value_;
        try {
            op1Value_ = this.op1_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return expectDouble(executeAndSpecialize(ex.getResult(), op2Value));
        }
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return expectDouble(executeAndSpecialize(op1Value_, ex.getResult()));
        }
        assert (state & 0b1000) != 0 /* is-active mul(double, int) */;
        return mul(op1Value_, op2Value_);
    }

    private double executeDouble_generic9(VirtualFrame frameValue, int state) throws UnexpectedResultException {
        Object op1Value_ = this.op1_.execute(frameValue);
        Object op2Value_ = this.op2_.execute(frameValue);
        if ((state & 0b110) != 0 /* is-active mul(double, double) || mul(int, double) */ && op2Value_ instanceof Double) {
            double op2Value__ = (double) op2Value_;
            if ((state & 0b10) != 0 /* is-active mul(double, double) */ && op1Value_ instanceof Double) {
                double op1Value__ = (double) op1Value_;
                return mul(op1Value__, op2Value__);
            }
            if ((state & 0b100) != 0 /* is-active mul(int, double) */ && op1Value_ instanceof Integer) {
                int op1Value__ = (int) op1Value_;
                return mul(op1Value__, op2Value__);
            }
        }
        if ((state & 0b1000) != 0 /* is-active mul(double, int) */ && op1Value_ instanceof Double) {
            double op1Value__ = (double) op1Value_;
            if (op2Value_ instanceof Integer) {
                int op2Value__ = (int) op2Value_;
                return mul(op1Value__, op2Value__);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return expectDouble(executeAndSpecialize(op1Value_, op2Value_));
    }

    @Override
    public int executeInt(VirtualFrame frameValue) throws UnexpectedResultException {
        int state = state_;
        int op1Value_;
        try {
            op1Value_ = this.op1_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return expectInteger(executeAndSpecialize(ex.getResult(), op2Value));
        }
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return expectInteger(executeAndSpecialize(op1Value_, ex.getResult()));
        }
        if ((state & 0b1) != 0 /* is-active mul(int, int) */) {
            return mul(op1Value_, op2Value_);
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return expectInteger(executeAndSpecialize(op1Value_, op2Value_));
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        int state = state_;
        try {
            if ((state & 0b11110) == 0 /* only-active mul(int, int) */ && state != 0  /* is-not mul(int, int) && mul(double, double) && mul(int, double) && mul(double, int) && mul(String, int) */) {
                executeInt(frameValue);
                return;
            } else if ((state & 0b10001) == 0 /* only-active mul(double, double) && mul(int, double) && mul(double, int) */ && state != 0  /* is-not mul(int, int) && mul(double, double) && mul(int, double) && mul(double, int) && mul(String, int) */) {
                executeDouble(frameValue);
                return;
            }
            execute(frameValue);
            return;
        } catch (UnexpectedResultException ex) {
            return;
        }
    }

    private Object executeAndSpecialize(Object op1Value, Object op2Value) {
        int state = state_;
        if (op1Value instanceof Integer) {
            int op1Value_ = (int) op1Value;
            if (op2Value instanceof Integer) {
                int op2Value_ = (int) op2Value;
                this.state_ = state = state | 0b1 /* add-active mul(int, int) */;
                return mul(op1Value_, op2Value_);
            }
        }
        if (op2Value instanceof Double) {
            double op2Value_ = (double) op2Value;
            if (op1Value instanceof Double) {
                double op1Value_ = (double) op1Value;
                this.state_ = state = state | 0b10 /* add-active mul(double, double) */;
                return mul(op1Value_, op2Value_);
            }
            if (op1Value instanceof Integer) {
                int op1Value_ = (int) op1Value;
                this.state_ = state = state | 0b100 /* add-active mul(int, double) */;
                return mul(op1Value_, op2Value_);
            }
        }
        if (op2Value instanceof Integer) {
            int op2Value_ = (int) op2Value;
            if (op1Value instanceof Double) {
                double op1Value_ = (double) op1Value;
                this.state_ = state = state | 0b1000 /* add-active mul(double, int) */;
                return mul(op1Value_, op2Value_);
            }
            if (op1Value instanceof String) {
                String op1Value_ = (String) op1Value;
                this.state_ = state = state | 0b10000 /* add-active mul(String, int) */;
                return mul(op1Value_, op2Value_);
            }
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.op1_, this.op2_}, op1Value, op2Value);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if ((state & (state - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    private static double expectDouble(Object value) throws UnexpectedResultException {
        if (value instanceof Double) {
            return (double) value;
        }
        throw new UnexpectedResultException(value);
    }

    private static int expectInteger(Object value) throws UnexpectedResultException {
        if (value instanceof Integer) {
            return (int) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static MJMulNode create(MJExpressionNode op1, MJExpressionNode op2) {
        return new MJMulNodeGen(op1, op2);
    }

}
