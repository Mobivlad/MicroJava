// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.expressions.relations;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.expressions.relations.MJNotEqualsNode;

@GeneratedBy(MJNotEqualsNode.class)
public final class MJNotEqualsNodeGen extends MJNotEqualsNode {

    @Child private MJExpressionNode op1_;
    @Child private MJExpressionNode op2_;
    @CompilationFinal private int state_;

    private MJNotEqualsNodeGen(MJExpressionNode op1, MJExpressionNode op2) {
        this.op1_ = op1;
        this.op2_ = op2;
    }

    @Override
    public Object execute(VirtualFrame frameValue) {
        int state = state_;
        if ((state & 0b111110) == 0 /* only-active isEquals(int, int) */ && state != 0  /* is-not isEquals(int, int) && isEquals(int, double) && isEquals(double, int) && isEquals(double, double) && isEquals(String, String) && isEquals(char, char) */) {
            return execute_int_int0(frameValue, state);
        } else if ((state & 0b111101) == 0 /* only-active isEquals(int, double) */ && state != 0  /* is-not isEquals(int, int) && isEquals(int, double) && isEquals(double, int) && isEquals(double, double) && isEquals(String, String) && isEquals(char, char) */) {
            return execute_int_double1(frameValue, state);
        } else if ((state & 0b111011) == 0 /* only-active isEquals(double, int) */ && state != 0  /* is-not isEquals(int, int) && isEquals(int, double) && isEquals(double, int) && isEquals(double, double) && isEquals(String, String) && isEquals(char, char) */) {
            return execute_double_int2(frameValue, state);
        } else if ((state & 0b110111) == 0 /* only-active isEquals(double, double) */ && state != 0  /* is-not isEquals(int, int) && isEquals(int, double) && isEquals(double, int) && isEquals(double, double) && isEquals(String, String) && isEquals(char, char) */) {
            return execute_double_double3(frameValue, state);
        } else if ((state & 0b11111) == 0 /* only-active isEquals(char, char) */ && state != 0  /* is-not isEquals(int, int) && isEquals(int, double) && isEquals(double, int) && isEquals(double, double) && isEquals(String, String) && isEquals(char, char) */) {
            return execute_char_char4(frameValue, state);
        } else {
            return execute_generic5(frameValue, state);
        }
    }

    private Object execute_int_int0(VirtualFrame frameValue, int state) {
        int op1Value_;
        try {
            op1Value_ = this.op1_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b1) != 0 /* is-active isEquals(int, int) */;
        return isEquals(op1Value_, op2Value_);
    }

    private Object execute_int_double1(VirtualFrame frameValue, int state) {
        int op1Value_;
        try {
            op1Value_ = this.op1_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b10) != 0 /* is-active isEquals(int, double) */;
        return isEquals(op1Value_, op2Value_);
    }

    private Object execute_double_int2(VirtualFrame frameValue, int state) {
        double op1Value_;
        try {
            op1Value_ = this.op1_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b100) != 0 /* is-active isEquals(double, int) */;
        return isEquals(op1Value_, op2Value_);
    }

    private Object execute_double_double3(VirtualFrame frameValue, int state) {
        double op1Value_;
        try {
            op1Value_ = this.op1_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b1000) != 0 /* is-active isEquals(double, double) */;
        return isEquals(op1Value_, op2Value_);
    }

    private Object execute_char_char4(VirtualFrame frameValue, int state) {
        char op1Value_;
        try {
            op1Value_ = this.op1_.executeCharacter(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        char op2Value_;
        try {
            op2Value_ = this.op2_.executeCharacter(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b100000) != 0 /* is-active isEquals(char, char) */;
        return isEquals(op1Value_, op2Value_);
    }

    private Object execute_generic5(VirtualFrame frameValue, int state) {
        Object op1Value_ = this.op1_.execute(frameValue);
        Object op2Value_ = this.op2_.execute(frameValue);
        if ((state & 0b11) != 0 /* is-active isEquals(int, int) || isEquals(int, double) */ && op1Value_ instanceof Integer) {
            int op1Value__ = (int) op1Value_;
            if ((state & 0b1) != 0 /* is-active isEquals(int, int) */ && op2Value_ instanceof Integer) {
                int op2Value__ = (int) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
            if ((state & 0b10) != 0 /* is-active isEquals(int, double) */ && op2Value_ instanceof Double) {
                double op2Value__ = (double) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
        }
        if ((state & 0b1100) != 0 /* is-active isEquals(double, int) || isEquals(double, double) */ && op1Value_ instanceof Double) {
            double op1Value__ = (double) op1Value_;
            if ((state & 0b100) != 0 /* is-active isEquals(double, int) */ && op2Value_ instanceof Integer) {
                int op2Value__ = (int) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
            if ((state & 0b1000) != 0 /* is-active isEquals(double, double) */ && op2Value_ instanceof Double) {
                double op2Value__ = (double) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
        }
        if ((state & 0b10000) != 0 /* is-active isEquals(String, String) */ && op1Value_ instanceof String) {
            String op1Value__ = (String) op1Value_;
            if (op2Value_ instanceof String) {
                String op2Value__ = (String) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
        }
        if ((state & 0b100000) != 0 /* is-active isEquals(char, char) */ && op1Value_ instanceof Character) {
            char op1Value__ = (char) op1Value_;
            if (op2Value_ instanceof Character) {
                char op2Value__ = (char) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    @Override
    public boolean executeBoolean(VirtualFrame frameValue) {
        int state = state_;
        if ((state & 0b111110) == 0 /* only-active isEquals(int, int) */ && state != 0  /* is-not isEquals(int, int) && isEquals(int, double) && isEquals(double, int) && isEquals(double, double) && isEquals(String, String) && isEquals(char, char) */) {
            return executeBoolean_int_int6(frameValue, state);
        } else if ((state & 0b111101) == 0 /* only-active isEquals(int, double) */ && state != 0  /* is-not isEquals(int, int) && isEquals(int, double) && isEquals(double, int) && isEquals(double, double) && isEquals(String, String) && isEquals(char, char) */) {
            return executeBoolean_int_double7(frameValue, state);
        } else if ((state & 0b111011) == 0 /* only-active isEquals(double, int) */ && state != 0  /* is-not isEquals(int, int) && isEquals(int, double) && isEquals(double, int) && isEquals(double, double) && isEquals(String, String) && isEquals(char, char) */) {
            return executeBoolean_double_int8(frameValue, state);
        } else if ((state & 0b110111) == 0 /* only-active isEquals(double, double) */ && state != 0  /* is-not isEquals(int, int) && isEquals(int, double) && isEquals(double, int) && isEquals(double, double) && isEquals(String, String) && isEquals(char, char) */) {
            return executeBoolean_double_double9(frameValue, state);
        } else if ((state & 0b11111) == 0 /* only-active isEquals(char, char) */ && state != 0  /* is-not isEquals(int, int) && isEquals(int, double) && isEquals(double, int) && isEquals(double, double) && isEquals(String, String) && isEquals(char, char) */) {
            return executeBoolean_char_char10(frameValue, state);
        } else {
            return executeBoolean_generic11(frameValue, state);
        }
    }

    private boolean executeBoolean_int_int6(VirtualFrame frameValue, int state) {
        int op1Value_;
        try {
            op1Value_ = this.op1_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b1) != 0 /* is-active isEquals(int, int) */;
        return isEquals(op1Value_, op2Value_);
    }

    private boolean executeBoolean_int_double7(VirtualFrame frameValue, int state) {
        int op1Value_;
        try {
            op1Value_ = this.op1_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b10) != 0 /* is-active isEquals(int, double) */;
        return isEquals(op1Value_, op2Value_);
    }

    private boolean executeBoolean_double_int8(VirtualFrame frameValue, int state) {
        double op1Value_;
        try {
            op1Value_ = this.op1_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        int op2Value_;
        try {
            op2Value_ = this.op2_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b100) != 0 /* is-active isEquals(double, int) */;
        return isEquals(op1Value_, op2Value_);
    }

    private boolean executeBoolean_double_double9(VirtualFrame frameValue, int state) {
        double op1Value_;
        try {
            op1Value_ = this.op1_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        double op2Value_;
        try {
            op2Value_ = this.op2_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b1000) != 0 /* is-active isEquals(double, double) */;
        return isEquals(op1Value_, op2Value_);
    }

    private boolean executeBoolean_char_char10(VirtualFrame frameValue, int state) {
        char op1Value_;
        try {
            op1Value_ = this.op1_.executeCharacter(frameValue);
        } catch (UnexpectedResultException ex) {
            Object op2Value = this.op2_.execute(frameValue);
            return executeAndSpecialize(ex.getResult(), op2Value);
        }
        char op2Value_;
        try {
            op2Value_ = this.op2_.executeCharacter(frameValue);
        } catch (UnexpectedResultException ex) {
            return executeAndSpecialize(op1Value_, ex.getResult());
        }
        assert (state & 0b100000) != 0 /* is-active isEquals(char, char) */;
        return isEquals(op1Value_, op2Value_);
    }

    private boolean executeBoolean_generic11(VirtualFrame frameValue, int state) {
        Object op1Value_ = this.op1_.execute(frameValue);
        Object op2Value_ = this.op2_.execute(frameValue);
        if ((state & 0b11) != 0 /* is-active isEquals(int, int) || isEquals(int, double) */ && op1Value_ instanceof Integer) {
            int op1Value__ = (int) op1Value_;
            if ((state & 0b1) != 0 /* is-active isEquals(int, int) */ && op2Value_ instanceof Integer) {
                int op2Value__ = (int) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
            if ((state & 0b10) != 0 /* is-active isEquals(int, double) */ && op2Value_ instanceof Double) {
                double op2Value__ = (double) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
        }
        if ((state & 0b1100) != 0 /* is-active isEquals(double, int) || isEquals(double, double) */ && op1Value_ instanceof Double) {
            double op1Value__ = (double) op1Value_;
            if ((state & 0b100) != 0 /* is-active isEquals(double, int) */ && op2Value_ instanceof Integer) {
                int op2Value__ = (int) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
            if ((state & 0b1000) != 0 /* is-active isEquals(double, double) */ && op2Value_ instanceof Double) {
                double op2Value__ = (double) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
        }
        if ((state & 0b10000) != 0 /* is-active isEquals(String, String) */ && op1Value_ instanceof String) {
            String op1Value__ = (String) op1Value_;
            if (op2Value_ instanceof String) {
                String op2Value__ = (String) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
        }
        if ((state & 0b100000) != 0 /* is-active isEquals(char, char) */ && op1Value_ instanceof Character) {
            char op1Value__ = (char) op1Value_;
            if (op2Value_ instanceof Character) {
                char op2Value__ = (char) op2Value_;
                return isEquals(op1Value__, op2Value__);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(op1Value_, op2Value_);
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        executeBoolean(frameValue);
        return;
    }

    private boolean executeAndSpecialize(Object op1Value, Object op2Value) {
        int state = state_;
        if (op1Value instanceof Integer) {
            int op1Value_ = (int) op1Value;
            if (op2Value instanceof Integer) {
                int op2Value_ = (int) op2Value;
                this.state_ = state = state | 0b1 /* add-active isEquals(int, int) */;
                return isEquals(op1Value_, op2Value_);
            }
            if (op2Value instanceof Double) {
                double op2Value_ = (double) op2Value;
                this.state_ = state = state | 0b10 /* add-active isEquals(int, double) */;
                return isEquals(op1Value_, op2Value_);
            }
        }
        if (op1Value instanceof Double) {
            double op1Value_ = (double) op1Value;
            if (op2Value instanceof Integer) {
                int op2Value_ = (int) op2Value;
                this.state_ = state = state | 0b100 /* add-active isEquals(double, int) */;
                return isEquals(op1Value_, op2Value_);
            }
            if (op2Value instanceof Double) {
                double op2Value_ = (double) op2Value;
                this.state_ = state = state | 0b1000 /* add-active isEquals(double, double) */;
                return isEquals(op1Value_, op2Value_);
            }
        }
        if (op1Value instanceof String) {
            String op1Value_ = (String) op1Value;
            if (op2Value instanceof String) {
                String op2Value_ = (String) op2Value;
                this.state_ = state = state | 0b10000 /* add-active isEquals(String, String) */;
                return isEquals(op1Value_, op2Value_);
            }
        }
        if (op1Value instanceof Character) {
            char op1Value_ = (char) op1Value;
            if (op2Value instanceof Character) {
                char op2Value_ = (char) op2Value;
                this.state_ = state = state | 0b100000 /* add-active isEquals(char, char) */;
                return isEquals(op1Value_, op2Value_);
            }
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.op1_, this.op2_}, op1Value, op2Value);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if ((state & (state - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    public static MJNotEqualsNode create(MJExpressionNode op1, MJExpressionNode op2) {
        return new MJNotEqualsNodeGen(op1, op2);
    }

}
